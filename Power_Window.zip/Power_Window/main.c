#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include "main.h"

void main()
{
    uint8_t USER, DOWN = 0, UP = 0, EXPR = 0, bottom;
    bool continue_flag;
    // Power_Window User interface
    printf("For Turn ignition on, press 1  ");
    printf("\nFor Turn ignition off, press 0: ");
    scanf("%d",&IGNITION);
    printf("For Close door, press 1  ");
    printf("\nFor open door, press 0:  ");
    scanf("%d",&DOOR_STATUS);
    continue_flag = true;

while (continue_flag == true){
        printf("Do you want to: \n");
        printf("-----------------------------------\n");
        printf("Move the window up, press 1 \n");
        printf("Move the window down, press 2\n");
        printf("Use the Express bottom, press 3\n");
        printf("Exit, press 0\n");
        scanf("%d",&USER);

        switch (USER){
            case 0:
                continue_flag = false;
                break;
            case 1:
                MOVING_UP_SWITCH = 1;
                UP = Power_Window_UP_Mode(IGNITION, DOOR_STATUS, MOVING_UP_SWITCH);
                printf("UP: %d\n", UP);
                if(UP == 0){
                    printf("Window does not go up");
                }
                else if (UP == 1){
                    printf("Window goes up");
                }
                else{
                    printf("Window does not move");
                }

                break;
            case 2:
                MOVING_DOWN_SWITCH = 1;
                DOWN = windowDown(IGNITION, DOOR_STATUS, MOVING_DOWN_SWITCH);
                printf("%d\n",DOWN);
                if(DOWN == 0){
                    printf("Window does not go down");
                }
                else if (DOWN == 2){
                    printf("Window goes down");
                }
                else{
                    printf("Window does not move");
                }
                break;
            case 3:
                OBSTACLE_SENSOR = 0;
                printf("Express Up, press 1\n");
                printf("Express Down, press 2\n");
                scanf("%d",&bottom);
                switch (bottom){
                    case 1:
                    ONE_TOUCH_EXPRESS_UP_DOWN = bottom;
                    EXPR = Express_Signal(IGNITION, DOOR_STATUS, ONE_TOUCH_EXPRESS_UP_DOWN, OBSTACLE_SENSOR);
                    printf("Window goes UP\n");
                    printf("%d\n", EXPR);
                    break;
                    case 2:
                    ONE_TOUCH_EXPRESS_UP_DOWN = bottom;
                    EXPR = Express_Signal(IGNITION, DOOR_STATUS, ONE_TOUCH_EXPRESS_UP_DOWN, OBSTACLE_SENSOR);
                    printf("Window goes DOWN\n");
                    printf("%d\n", EXPR);
                    break;
                    default:
                    printf("Incorrect option, choose again\n");
                }
                break;

            default:
                printf(" %d, Incorrect Option\n", USER);
        }
    }

}



