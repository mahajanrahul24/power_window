#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
uint16_t Express_Signal(uint8_t IGNITION, uint8_t DOOR_STATUS, uint8_t ONE_TOUCH_EXPRESS_UP_DOWN);

void main()
{
    uint8_t DOOR_STATUS, ONE_TOUCH_EXPRESS_UP_DOWN =1 , IGNITION =1;
    uint8_t POWER_WINDOW_STATUS, STATUS;

    STATUS = Express_Signal(IGNITION, DOOR_STATUS, ONE_TOUCH_EXPRESS_UP_DOWN);
    printf("%d",STATUS);

}

uint16_t Express_Signal(uint8_t IGNITION, uint8_t DOOR_STATUS, uint8_t ONE_TOUCH_EXPRESS_UP_DOWN)
{
    uint8_t POWER_WINDOW_STATUS=0;
    bool WINDOW_FULLY_OPEN =1, WINDOW_FULLY_CLOSED, WINDOW_IN_MIDDLE;
   while(ONE_TOUCH_EXPRESS_UP_DOWN == 1){
        if(IGNITION == 1 && (WINDOW_FULLY_OPEN == 1)){
            for(int i=0; i<150; i++){
                    POWER_WINDOW_STATUS = 4 + POWER_WINDOW_STATUS;
            }
            if(POWER_WINDOW_STATUS == 600){
                    WINDOW_FULLY_CLOSED = 1;
                    WINDOW_IN_MIDDLE = 0;
            }
        }
        if(IGNITION == 1 && (WINDOW_IN_MIDDLE == 1)){
           for(int i=0; i<150; i++){
                    POWER_WINDOW_STATUS = 4 + POWER_WINDOW_STATUS;
            }
            if(POWER_WINDOW_STATUS == 600){
                    WINDOW_FULLY_CLOSED = 1;
                    WINDOW_IN_MIDDLE = 0;
            }
           }
           if(WINDOW_FULLY_CLOSED == 1){
                ONE_TOUCH_EXPRESS_UP_DOWN = 0;
                break;
           }
    return POWER_WINDOW_STATUS;
   }
}

