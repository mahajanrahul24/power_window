#include "prueba_f.h"
void express_bottom(void){
    int bottom;
    printf("Express Up, press 1\n");
    printf("Express Down, press 2\n");
    scanf("%d",&bottom);
    switch (bottom){
    case 1:
        printf("%d\n",bottom);
        break;
    case 2:
        printf("%d\n",bottom);
        break;
    default:
        printf("Incorrect option, choose again\n");
    }
}
